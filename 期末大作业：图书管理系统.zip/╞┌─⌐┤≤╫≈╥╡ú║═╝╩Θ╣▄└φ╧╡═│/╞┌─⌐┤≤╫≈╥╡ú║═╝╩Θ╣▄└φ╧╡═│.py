import tkinter as tk  # 使用Tkinter前需要先导入
import tkinter.messagebox
import os

###------------------------------------以下为全局变量的定义--------------------------------------------------------------###

user_choice_num = 0 #一个用来表示用户选择的变量
books = []  #用来保存当前图书馆中已有的图书
Is = []

###----------------------------------以下为对书籍“类”的创建------------------------------------------------------------###

class Book(object):
    def __init__(self,name,author,state,book_position):
        self.name = name
        self.author = author
        self.state = state   # 判断书的借阅状态，0：借出 1：未借出
        self.book_position = book_position
        

f = open("library_data.csv","r")
fw = open("library_data_1.csv","w")
for line in f:
    cnt=0
    line = line.replace("\n","")
    Is.append(line.split(","))
    for i in range(len(Is)):
        for j in range(len(Is[i])):
            if j==0:
                name = Is[i][j]
            if j==1:
                author = Is[i][j]
            if j==2:
                state = Is[i][j]
            if j==3:
                position = Is[i][j]
            
    books.append(Book(name,author,state,position))

        
#print(Is)   测试用


#b1 = Book("三体", "刘慈欣", 1, "TP156")
#b2 = Book("白夜行", "东野圭吾", 1, "TP755")
#b3 = Book("Python语言程序设计基础", "黄天羽", 1, "TP761")
#b4 = Book("放学后", "东野圭吾", 1, "TP706")
#b5 = Book("北鸢", "葛亮", 1, "TP711")
#b6 = Book("秘密", "东野圭吾", 1, "TP755")
#b7 = Book("双城记", "狄更斯", 1, "TP986")
#b8 = Book("海边的卡夫卡", "村上春树", 1, "TP006")
#b9 = Book("纸牌屋", "道布斯", 1, "TP026")
#b10 = Book("解忧杂货店", "东野圭吾", 1, "TP752")
#b11 = Book("超新星纪元", "刘慈欣", 1, "TP857")

#books.append(b1)
#books.append(b2)
#books.append(b3)
#books.append(b4)
#books.append(b5)
#books.append(b6)
#books.append(b7)


###-----------------------------------以下为设置的窗口、标签、按钮、文本框等的定义--------------------------------------------###
# 实例化object，建立窗口window
window = tk.Tk()
 
#给窗口的可视化起名字
window.title('华小科图书馆系统')
 
# 设定窗口的大小(长 * 宽)
window.geometry('500x300')  # 这里的乘是小x

#设置一个向用户显示查询结果的窗口
t_print_check = tk.Text(window, bg='white',height=3)
t_print_add = tk.Text(window, bg='white',height=3)
t_print_borrow = tk.Text(window, bg='white',height=3)
t_print_return = tk.Text(window, bg='white',height=3)
t_print_evaluate = tk.Text(window, bg='white',height=3)


var_option = tk.StringVar() 

#*******************************check函数中的三个按钮********************************************************************#
#用户点击确认按钮
def user_press_yes_check():
    global user_choice_num
    flag=1
    name_current =e_check.get()
    for book in books:
        if book.name == name_current:
            t_print_check.tag_config("tag_1", backgroun="yellow")
            t_print_check.insert("end",f"书名：《{book.name}》，作者：<{book.author}>,状态：<{book.state}>,位置：<{book.book_position}>","tag_1")
            flag=0
            break
    if flag==1:
        t_print_check.tag_config("tag_2", backgroun="red")
        t_print_check.insert("end",f"你查询的书籍《{name_current}》不在系统中！请点击“清除”后重新输入！","tag_2")

#用户点击清除按钮
def user_press_clear_check():
    t_print_check.delete(1.0, "end")

#用户点击返回按钮
def user_press_back_check():
    #清除一些按钮
    l_help_check.forget()
    e_check.forget()   
    l_button_affirmation_check.forget()
    l_button_clear_check.forget()
    l_button_back_check.forget()
    t_print_check.forget()

    #重新放置一些按钮
    l_option.pack()
    r1.pack()
    r2.pack()
    r3.pack()
    r4.pack()
    r5.pack()
    r6.pack()
    

#*******************************add函数中的三个按钮********************************************************************#
#用户点击确认按钮
def user_press_yes_add():
    global user_choice_num
    
    name = e_add_1.get()
    author = e_add_2.get()
    position = e_add_3.get()
    if name !='' and author !='' and position !='':
        books.append(Book(name,author,'1',position))
        t_print_add.insert("end",f"添加成功！ 书名：《{name}》，作者：<{author}>,状态：1,位置：<{position}>")

    else:    
        t_print_add.tag_config("tag_2", backgroun="red")
        t_print_add.insert("end","格式错误，请点“清除”后重新输入，谢谢！")

#用户点击清除按钮
def user_press_clear_add():
    t_print_add.delete(1.0, "end")

#用户点击返回按钮
def user_press_back_add():
    #清除一些按钮
    l_help_add.forget()
    l_add_1.place_forget()
    e_add_1.place_forget()
    l_add_2.place_forget()
    e_add_2.place_forget()
    l_add_3.place_forget()
    e_add_3.place_forget()

    #清除“确定”、“清除”、“返回”按钮       
    l_button_affirmation_add.forget()
    l_button_clear_add.forget()
    l_button_back_add.forget()
    t_print_add.place_forget()

    #重新放置一些按钮
    l_option.pack()
    r1.pack()
    r2.pack()
    r3.pack()
    r4.pack()
    r5.pack()
    r6.pack()

#*******************************borrow函数中的三个按钮********************************************************************#
#用户点击确认按钮
def user_press_yes_borrow():
    global user_choice_num
    flag=1
    name_current =e_borrow.get()
    for book in books:
        if book.name == name_current and book.state=='1':
            t_print_borrow.tag_config("tag_1", backgroun="yellow")
            t_print_borrow.insert("end",f"借阅成功！书名：《{book.name}》，作者：<{book.author}> , 位置：<{book.book_position}>","tag_1")
            flag=0
            book.state = '0'
            break
            
    if flag==1:
        t_print_borrow.tag_config("tag_2", backgroun="red")
        t_print_borrow.insert("end",f"您想借阅的书籍《{name_current}》不在系统中！请点击“清除”后重新输入！","tag_2")

#用户点击清除按钮
def user_press_clear_borrow():
    t_print_borrow.delete(1.0, "end")

#用户点击返回按钮
def user_press_back_borrow():
    #清除一些按钮
    l_help_borrow.forget()
    e_borrow.forget()   
    l_button_affirmation_borrow.forget()
    l_button_clear_borrow.forget()
    l_button_back_borrow.forget()
    t_print_borrow.forget()

    #重新放置一些按钮
    l_option.pack()
    r1.pack()
    r2.pack()
    r3.pack()
    r4.pack()
    r5.pack()
    r6.pack()
    
#*******************************return函数中的三个按钮********************************************************************#
#用户点击确认按钮
def user_press_yes_return():
    global user_choice_num
    flag=1
    name_current =e_return.get()
    for book in books:
        if book.name == name_current and book.state == '0':
            book.state = '1'
            t_print_return.tag_config("tag_1", backgroun="yellow")
            t_print_return.insert("end",f"归还成功！书名：《{book.name}》，作者：<{book.author}>,状态：<{book.state}>,位置：<{book.book_position}>","tag_1")
            flag=0
    if flag==1:
        t_print_return.tag_config("tag_2", backgroun="red")
        t_print_return.insert("end",f"您归还的书籍《{name_current}》与借阅的不一致！请点击“清除”后重新输入！","tag_2")

#用户点击清除按钮
def user_press_clear_return():
    t_print_return.delete(1.0, "end")

#用户点击返回按钮
def user_press_back_return():
    #清除一些按钮
    l_help_return.forget()
    e_return.forget()   
    l_button_affirmation_return.forget()
    l_button_clear_return.forget()
    l_button_back_return.forget()
    t_print_return.forget()

    #重新放置一些按钮
    l_option.pack()
    r1.pack()
    r2.pack()
    r3.pack()
    r4.pack()
    r5.pack()
    r6.pack()
    
#*******************************evaluate函数中的按钮********************************************************************#
#用户点击确认按钮
def user_press_yes_evaluate():
    tkinter.messagebox.showinfo(title='消息提示', message='评价成功！')
    


#用户点击返回按钮
def user_press_back_evaluate():
    #清除一些按钮
    l_button_affirmation_evaluate.forget()
    l_button_back_evaluate.forget()
    s_evaluate.forget()
    l_help_evaluate.forget()

    #重新放置一些按钮
    l_option.pack()
    r1.pack()
    r2.pack()
    r3.pack()
    r4.pack()
    r5.pack()
    r6.pack()

#**************************************************************************************************************************#
            
#用户最初选择的希望进行的操作，定义选项触发函数功能
def print_selection():
    global user_choice_num
    
    l_option.config(text='您选择的是 ：' + var_option.get())
    
    if var_option.get() == '查询图书':
        user_choice_num = 1
        User_Check_Book() #进入书籍查询函数
    if var_option.get() == '添加图书':
        user_choice_num = 2
        User_Add_Book()  #进入书籍增添函数
    if var_option.get() == '借阅图书':
        user_choice_num = 3
        User_Borrow_Book()  #进入书籍借阅函数
    if var_option.get() == '归还图书':
        user_choice_num = 4
        User_Return_Book()  #进入书籍归还函数
    if var_option.get() == '评价':
        user_choice_num = 5
        User_Evaluate()  #进入评价系统
    if var_option.get() == '正常退出系统':
        user_choice_num = 6
        User_Exit()  #退出系统并保存数据


 
# 在图形界面上设定标签
l_welcome = tk.Label(window, text='您好！欢迎来到华小科图书馆系统', bg='white', font=('Arial', 12), width=30, height=2)
# 说明： bg为背景，font为字体，width为长，height为高，这里的长和高是字符的长和高，比如height=2,就是标签有2个字符这么高


#用户输入希望操作的书籍（框）
e_check = tk.Entry(window, show=None, font=('Arial', 14))  # 显示成明文形式
e_add_1 = tk.Entry(window, show=None, font=('Arial', 10))  # 输入书名
e_add_2 = tk.Entry(window, show=None, font=('Arial', 10))  # 输入书名
e_add_3 = tk.Entry(window, show=None, font=('Arial', 10))  # 输入书名
e_borrow = tk.Entry(window, show=None, font=('Arial', 14))  # 显示成明文形式
e_return = tk.Entry(window, show=None, font=('Arial', 14))  # 显示成明文形式
s_evaluate = tk.Scale(window, label='您的满意是我们最大的动力', from_=0, to=10, orient=tk.HORIZONTAL, length=200, showvalue=0,tickinterval=2, resolution=0.01)

#设定一个button按钮，表示对文本框中的输入“确定”
l_button_affirmation_check = tk.Button(window, text='确定', font=('Arial', 8), width=6, height=1, command=user_press_yes_check)
l_button_affirmation_add = tk.Button(window, text='确定', font=('Arial', 8), width=6, height=1, command=user_press_yes_add)
l_button_affirmation_borrow = tk.Button(window, text='确定', font=('Arial', 8), width=6, height=1, command=user_press_yes_borrow)
l_button_affirmation_return = tk.Button(window, text='确定', font=('Arial', 8), width=6, height=1, command=user_press_yes_return)
l_button_affirmation_evaluate = tk.Button(window, text='确定', font=('Arial', 8), width=6, height=1, command=user_press_yes_evaluate)

#设定一个button按钮，表示对文本框中的输入“清除”
l_button_clear_check = tk.Button(window, text='清除', font=('Arial', 8), width=6, height=1, command=user_press_clear_check)
l_button_clear_add = tk.Button(window, text='清除', font=('Arial', 8), width=6, height=1, command=user_press_clear_add)
l_button_clear_borrow = tk.Button(window, text='清除', font=('Arial', 8), width=6, height=1, command=user_press_clear_borrow)
l_button_clear_return = tk.Button(window, text='清除', font=('Arial', 8), width=6, height=1, command=user_press_clear_return)

#设定一个button按钮，用于返回到上一页面
l_button_back_check = tk.Button(window, text='返回', font=('Arial', 8), width=6, height=1, command=user_press_back_check)
l_button_back_add = tk.Button(window, text='返回', font=('Arial', 8), width=6, height=1, command=user_press_back_add)
l_button_back_borrow = tk.Button(window, text='返回', font=('Arial', 8), width=6, height=1, command=user_press_back_borrow)
l_button_back_return = tk.Button(window, text='返回', font=('Arial', 8), width=6, height=1, command=user_press_back_return)
l_button_back_evaluate = tk.Button(window, text='返回', font=('Arial', 8), width=6, height=1, command=user_press_back_evaluate)

#此处设定一个操作提示框，用来引导用户进行第二步的操作
l_help_check = tk.Label(window, text='请输入您想查询的书籍', bg='green', font=('Arial', 12), width=30, height=2)
l_help_add = tk.Label(window, text='请输入您想增添的书籍', bg='green', font=('Arial', 12), width=30, height=2)
l_add_1 = tk.Label(window,text='书名',bg='yellow',font=('Arial', 12))
l_add_2 = tk.Label(window,text='作者',bg='yellow',font=('Arial', 12))
l_add_3 = tk.Label(window,text='位置',bg='yellow',font=('Arial', 12))
l_help_borrow = tk.Label(window, text='请输入您想借阅的书籍', bg='green', font=('Arial', 12), width=30, height=2)
l_help_return = tk.Label(window, text='请输入您想归还的书籍', bg='green', font=('Arial', 12), width=30, height=2)
l_help_evaluate = tk.Label(window, text='请对我们的工作进行评价', bg='green', font=('Arial', 12), width=30, height=2)


#用户选项（框）
l_option = tk.Label(window, bg='yellow', width=20, text='请选择您想进行的操作')


# 创建五个radiobutton选项，其中variable=var, value='A'的意思就是，当我们鼠标选中了其中一个选项，把value的值A放到变量var中，然后赋值给variable
r1 = tk.Radiobutton(window, text='Option A：查询图书', variable=var_option, value='查询图书', command=print_selection)
r2 = tk.Radiobutton(window, text='Option B：添加图书', variable=var_option, value='添加图书', command=print_selection)
r3 = tk.Radiobutton(window, text='Option C：借阅图书', variable=var_option, value='借阅图书', command=print_selection)
r4 = tk.Radiobutton(window, text='Option D：归还图书', variable=var_option, value='归还图书', command=print_selection)
r5 = tk.Radiobutton(window, text='Option E：评价', variable=var_option, value='评价', command=print_selection)
r6 = tk.Radiobutton(window, text='Option F：正常退出系统', variable=var_option, value='正常退出系统', command=print_selection)

###----------------------------------------以下为函数定义部分--------------------------------------------------------###
      
#查询图书
def User_Check_Book():
    #清除四个选项栏
    r1.forget()
    r2.forget()
    r3.forget()
    r4.forget()
    r5.forget()
    r6.forget()
    l_option.forget()

    #放置用户引导文本
    l_help_check.pack()

    #将用户输入框放上去
    e_check.pack()

    #放置“确定”、“清除”、“返回”按钮       
    l_button_affirmation_check.pack()
    l_button_clear_check.pack()
    l_button_back_check.pack()

    #放置查询结果显示文本框
    t_print_check.pack()

    
#增添图书
def User_Add_Book():
    r1.forget()
    r2.forget()
    r3.forget()
    r4.forget()
    r5.forget()
    r6.forget()
    l_option.forget()

    #放置用户引导文本
    l_help_add.pack()

    #将用户输入框放上去
    l_add_1.place(x=20,y=200,width=30,height=20)
    e_add_1.place(x=50,y=200,width=80,height=20)
    l_add_2.place(x=200,y=200,width=30,height=20)
    e_add_2.place(x=230,y=200,width=80,height=20)
    l_add_3.place(x=380,y=200,width=30,height=20)
    e_add_3.place(x=410,y=200,width=80,height=20)

    #放置“确定”、“清除”、“返回”按钮       
    l_button_affirmation_add.pack()
    l_button_clear_add.pack()
    l_button_back_add.pack()

    #放置查询结果显示文本框
    t_print_add.place(x=20,y=230,width=470,height=60)

    

    
#借阅图书
def User_Borrow_Book():
    #清除四个选项栏
    r1.forget()
    r2.forget()
    r3.forget()
    r4.forget()
    r5.forget()
    r6.forget()
    l_option.forget()

    #放置用户引导文本
    l_help_borrow.pack()

    #将用户输入框放上去
    e_borrow.pack()

    #放置“确定”、“清除”、“返回”按钮       
    l_button_affirmation_borrow.pack()
    l_button_clear_borrow.pack()
    l_button_back_borrow.pack()

    #放置查询结果显示文本框
    t_print_borrow.pack()

    
#归还图书
def User_Return_Book():
    #清除四个选项栏
    r1.forget()
    r2.forget()
    r3.forget()
    r4.forget()
    r5.forget()
    r6.forget()
    l_option.forget()

    #放置用户引导文本
    l_help_return.pack()

    #将用户输入框放上去
    e_return.pack()

    #放置“确定”、“清除”、“返回”按钮       
    l_button_affirmation_return.pack()
    l_button_clear_return.pack()
    l_button_back_return.pack()

    #放置查询结果显示文本框
    t_print_return.pack()

    
#评价
def User_Evaluate():
    #清除四个选项栏
    r1.forget()
    r2.forget()
    r3.forget()
    r4.forget()
    r5.forget()
    r6.forget()
    l_option.forget()

    #放置用户引导文本
    l_help_evaluate.pack()

    #放置scale框
    s_evaluate.pack()
    
    #放置“确定”、“返回”按钮       
    l_button_affirmation_evaluate.pack()
    l_button_back_evaluate.pack()


def User_Exit():
    for book in books:
        Is_1=[]
        Is_1.append(book.name)
        Is_1.append(book.author)
        Is_1.append(book.state)
        Is_1.append(book.book_position)
        fw.write(",".join(Is_1)+"\n")
    f.close()
    fw.close()
    os.remove("./library_data.csv")
    os.rename("./library_data_1.csv","./library_data.csv")
    exit(0)  
    #print(Is_1)   测试用
        

###----------------------------------------以下为主函数部分---------------------------------------------------------###

l_welcome.pack()    # Label内容content区域放置位置，自动调节尺寸

#放置显示用户第一次选择的操作框
l_option.pack()

r1.pack()
r2.pack()
r3.pack()
r4.pack()
r5.pack()
r6.pack()

# 主窗口循环显示
window.mainloop()
